﻿var app = app || angular.module('fronterApp',[]);


function FronterController($scope) {
    $scope.to_day_text = moment().format('Do MMMM YYYY');
}

app.controller('fronterController', ['$scope', FronterController]);